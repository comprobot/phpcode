	$.validator.setDefaults({
		submitHandler: function() {
			alert("submitted!");
		}
	});

	

$(document).ready(function() {
	


	
$("#register").click(function() {
//var name = $("#name").val();




$("#signupForm").validate({
	
	       rules: {
				
				last_name: "required",
				first_name: "required"
				
				/*
				,
				username: {
					required: true,
					minlength: 2
				},
				password: {
					required: true,
					minlength: 5
				},
				confirm_password: {
					required: true,
					minlength: 5,
					equalTo: "#password"
				},
				email: {
					required: true,
					email: true
				},
				topic: {
					required: "#newsletter:checked",
					minlength: 2
				},
				agree: "required"
				*/
			},
			messages: {
				firstname: "Please enter your firstname",
				lastname: "Please enter your lastname"
				/*
				,
				
				username: {
					required: "Please enter a username",
					minlength: "Your username must consist of at least 2 characters"
				},
				password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 5 characters long"
				},
				confirm_password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 5 characters long",
					equalTo: "Please enter the same password as above"
				},
				email: "Please enter a valid email address",
				agree: "Please accept our policy",
				topic: "Please select at least 2 topics"
				*/
			}
		});
	
	
	
	
	


var username = $("#username").val();
var first_name = $("#first_name").val();
var last_name = $("#last_name").val();

var area_code = $("#area_code").val();
var phone = $("#phone").val();
var email = $("#email").val();
var password = $("#password").val();
var cpassword = $("#cpassword").val();
var title = $("#title").val();


console.log(username+" "+first_name+" "+last_name+" "+area_code+" "+phone+" "+email+" "+password+" "+cpassword+title);

if (username == '' || first_name == '' || password == '' || cpassword == '' ||  last_name == ''  ||  area_code == '' ||  phone == '' ||  email == '' ) {
alert("Please fill all fields...!!!!!!");
} else if ((password.length) < 8) {
alert("Password should at least 8 character in length...!!!!!!");
} else if (!(password).match(cpassword)) {
alert("Your passwords don't match. Try again?");
} else {




	
	
$.post("register.php", {
name1: name,
email1: email,
password1: password
}, function(data) {
if (data == 'You have Successfully Registered.....') {
$("form")[0].reset();
}
alert(data);
});



}
});
});