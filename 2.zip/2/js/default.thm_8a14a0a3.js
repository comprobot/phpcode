window.skins={};
                function __extends(d, b) {
                    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
                        function __() {
                            this.constructor = d;
                        }
                    __.prototype = b.prototype;
                    d.prototype = new __();
                };
                window.generateEUI = {};
                generateEUI.paths = {};
                generateEUI.styles = undefined;
                generateEUI.skins = {"eui.Button":"resource/eui_skins/ButtonSkin.exml","eui.CheckBox":"resource/eui_skins/CheckBoxSkin.exml","eui.HScrollBar":"resource/eui_skins/HScrollBarSkin.exml","eui.HSlider":"resource/eui_skins/HSliderSkin.exml","eui.Panel":"resource/eui_skins/PanelSkin.exml","eui.TextInput":"resource/eui_skins/TextInputSkin.exml","eui.ProgressBar":"resource/eui_skins/ProgressBarSkin.exml","eui.RadioButton":"resource/eui_skins/RadioButtonSkin.exml","eui.Scroller":"resource/eui_skins/ScrollerSkin.exml","eui.ToggleSwitch":"resource/eui_skins/ToggleSwitchSkin.exml","eui.VScrollBar":"resource/eui_skins/VScrollBarSkin.exml","eui.VSlider":"resource/eui_skins/VSliderSkin.exml","eui.ItemRenderer":"resource/eui_skins/ItemRendererSkin.exml"};generateEUI.paths['resource/eui_skins/ButtonSkin.exml'] = window.skins.ButtonSkin = (function (_super) {
	__extends(ButtonSkin, _super);
	function ButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
	}
	var _proto = ButtonSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return ButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/CheckBoxSkin.exml'] = window.skins.CheckBoxSkin = (function (_super) {
	__extends(CheckBoxSkin, _super);
	function CheckBoxSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_disabled_png")
				])
		];
	}
	var _proto = CheckBoxSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "checkbox_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return CheckBoxSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HScrollBarSkin.exml'] = window.skins.HScrollBarSkin = (function (_super) {
	__extends(HScrollBarSkin, _super);
	function HScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = HScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 8;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.verticalCenter = 0;
		t.width = 30;
		return t;
	};
	return HScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HSliderSkin.exml'] = window.skins.HSliderSkin = (function (_super) {
	__extends(HSliderSkin, _super);
	function HSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = HSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.height = 6;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_sb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.source = "thumb_png";
		t.verticalCenter = 0;
		return t;
	};
	return HSliderSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ItemRendererSkin.exml'] = window.skins.ItemRendererSkin = (function (_super) {
	__extends(ItemRendererSkin, _super);
	function ItemRendererSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data"],[0],this.labelDisplay,"text");
	}
	var _proto = ItemRendererSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "Tahoma";
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	return ItemRendererSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/PanelSkin.exml'] = window.skins.PanelSkin = (function (_super) {
	__extends(PanelSkin, _super);
	function PanelSkin() {
		_super.call(this);
		this.skinParts = ["titleDisplay","moveArea","closeButton"];
		
		this.minHeight = 230;
		this.minWidth = 450;
		this.elementsContent = [this._Image1_i(),this.moveArea_i(),this.closeButton_i()];
	}
	var _proto = PanelSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(2,2,12,12);
		t.source = "border_png";
		t.top = 0;
		return t;
	};
	_proto.moveArea_i = function () {
		var t = new eui.Group();
		this.moveArea = t;
		t.height = 45;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image2_i(),this.titleDisplay_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "header_png";
		t.top = 0;
		return t;
	};
	_proto.titleDisplay_i = function () {
		var t = new eui.Label();
		this.titleDisplay = t;
		t.fontFamily = "Tahoma";
		t.left = 15;
		t.right = 5;
		t.size = 20;
		t.textColor = 0xFFFFFF;
		t.verticalCenter = 0;
		t.wordWrap = false;
		return t;
	};
	_proto.closeButton_i = function () {
		var t = new eui.Button();
		this.closeButton = t;
		t.bottom = 5;
		t.horizontalCenter = 0;
		t.label = "close";
		return t;
	};
	return PanelSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ProgressBarSkin.exml'] = window.skins.ProgressBarSkin = (function (_super) {
	__extends(ProgressBarSkin, _super);
	function ProgressBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb","labelDisplay"];
		
		this.minHeight = 18;
		this.minWidth = 30;
		this.elementsContent = [this._Image1_i(),this.thumb_i(),this.labelDisplay_i()];
	}
	var _proto = ProgressBarSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_pb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.percentHeight = 100;
		t.source = "thumb_pb_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.horizontalCenter = 0;
		t.size = 15;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		return t;
	};
	return ProgressBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/RadioButtonSkin.exml'] = window.skins.RadioButtonSkin = (function (_super) {
	__extends(RadioButtonSkin, _super);
	function RadioButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_disabled_png")
				])
		];
	}
	var _proto = RadioButtonSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "radiobutton_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return RadioButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ScrollerSkin.exml'] = window.skins.ScrollerSkin = (function (_super) {
	__extends(ScrollerSkin, _super);
	function ScrollerSkin() {
		_super.call(this);
		this.skinParts = ["horizontalScrollBar","verticalScrollBar"];
		
		this.minHeight = 20;
		this.minWidth = 20;
		this.elementsContent = [this.horizontalScrollBar_i(),this.verticalScrollBar_i()];
	}
	var _proto = ScrollerSkin.prototype;

	_proto.horizontalScrollBar_i = function () {
		var t = new eui.HScrollBar();
		this.horizontalScrollBar = t;
		t.bottom = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.verticalScrollBar_i = function () {
		var t = new eui.VScrollBar();
		this.verticalScrollBar = t;
		t.percentHeight = 100;
		t.right = 0;
		return t;
	};
	return ScrollerSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/TextInputSkin.exml'] = window.skins.TextInputSkin = (function (_super) {
	__extends(TextInputSkin, _super);
	function TextInputSkin() {
		_super.call(this);
		this.skinParts = ["textDisplay","promptDisplay"];
		
		this.minHeight = 40;
		this.minWidth = 300;
		this.elementsContent = [this._Image1_i(),this._Rect1_i(),this.textDisplay_i()];
		this.promptDisplay_i();
		
		this.states = [
			new eui.State ("normal",
				[
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("textDisplay","textColor",0xff0000)
				])
			,
			new eui.State ("normalWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
			,
			new eui.State ("disabledWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
		];
	}
	var _proto = TextInputSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.percentHeight = 100;
		t.percentWidth = 100;
		return t;
	};
	_proto.textDisplay_i = function () {
		var t = new eui.EditableText();
		this.textDisplay = t;
		t.height = 24;
		t.left = "10";
		t.right = "10";
		t.size = 20;
		t.textColor = 0x000000;
		t.verticalCenter = "0";
		t.percentWidth = 100;
		return t;
	};
	_proto.promptDisplay_i = function () {
		var t = new eui.Label();
		this.promptDisplay = t;
		t.height = 24;
		t.left = 10;
		t.right = 10;
		t.size = 20;
		t.textColor = 0xa9a9a9;
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	return TextInputSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ToggleSwitchSkin.exml'] = window.skins.ToggleSwitchSkin = (function (_super) {
	__extends(ToggleSwitchSkin, _super);
	function ToggleSwitchSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i()];
		this.states = [
			new eui.State ("up",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
		];
	}
	var _proto = ToggleSwitchSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.source = "on_png";
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.horizontalCenter = -18;
		t.source = "handle_png";
		t.verticalCenter = 0;
		return t;
	};
	return ToggleSwitchSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VScrollBarSkin.exml'] = window.skins.VScrollBarSkin = (function (_super) {
	__extends(VScrollBarSkin, _super);
	function VScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 20;
		this.minWidth = 8;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = VScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 30;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.width = 8;
		return t;
	};
	return VScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VSliderSkin.exml'] = window.skins.VSliderSkin = (function (_super) {
	__extends(VSliderSkin, _super);
	function VSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 30;
		this.minWidth = 25;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = VSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_png";
		t.width = 7;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.horizontalCenter = 0;
		t.source = "thumb_png";
		return t;
	};
	return VSliderSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/custom/AlertUI.exml'] = window.AlertUI = (function (_super) {
	__extends(AlertUI, _super);
	function AlertUI() {
		_super.call(this);
		this.skinParts = ["btn","label"];
		
		this.height = 1080;
		this.width = 1716;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.btn_i(),this.label_i()];
	}
	var _proto = AlertUI.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.54;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "small_pop_ups_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.btn_i = function () {
		var t = new eui.Image();
		this.btn = t;
		t.horizontalCenter = -0.5;
		t.source = "btn_sure_png";
		t.y = 570.79;
		return t;
	};
	_proto.label_i = function () {
		var t = new eui.Label();
		this.label = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.horizontalCenter = 0;
		t.size = 36;
		t.text = "null";
		t.textAlign = "center";
		t.width = 650;
		t.y = 464.79;
		return t;
	};
	return AlertUI;
})(eui.Skin);generateEUI.paths['resource/eui_skins/custom/InfoPanel.exml'] = window.infoPanal = (function (_super) {
	__extends(infoPanal, _super);
	function infoPanal() {
		_super.call(this);
		this.skinParts = ["bankerRate","drawRate","playerRate","banker","player","bankerD","draw","pointDraw","bankerB","playerB","playD","drawArea","history","localHistoryG","localHistory","playerR1","playerR2","playerR3","bankerR1","bankerR2","bankerR3","totalWin","bankerWin","bankerDWin","bankerBWin","drawWin","playerWin","playerDWin","playBWin","pointDrawWin","settle","tipsContent","tips","sourceCodeLabel","sourceCodeG","gameName","creator","contractAddr","createTime","balance","historyCoin","gameInfo","close"];
		
		this.height = 1080;
		this.width = 1716;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.history_i(),this.localHistory_i(),this.settle_i(),this.tips_i(),this.sourceCodeG_i(),this.gameInfo_i(),this.close_i()];
	}
	var _proto = infoPanal.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.56;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "pop_ups_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.history_i = function () {
		var t = new eui.Group();
		this.history = t;
		t.anchorOffsetX = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.visible = false;
		t.elementsContent = [this._Image2_i(),this._Image3_i(),this._Image4_i(),this._Image5_i(),this._Image6_i(),this._Image7_i(),this.bankerRate_i(),this.drawRate_i(),this.playerRate_i(),this.banker_i(),this.player_i(),this.bankerD_i(),this.draw_i(),this.pointDraw_i(),this.bankerB_i(),this.playerB_i(),this.playD_i(),this.drawArea_i(),this._Image8_i(),this._Image9_i(),this._Image10_i(),this._Image11_i(),this._Image12_i(),this._Image13_i(),this._Image14_i(),this._Image15_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "title_text_dzld_png";
		t.x = 725;
		t.y = 132.24;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "icon_png";
		t.x = 240.92;
		t.y = 206.24;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "win_ping_png";
		t.x = 786.84;
		t.y = 211.5;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "win_zhuang_png";
		t.x = 369.7;
		t.y = 211.5;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.source = "win_xian_png";
		t.x = 1071.1;
		t.y = 211.5;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.source = "bg_png";
		t.x = 232;
		t.y = 318.24;
		return t;
	};
	_proto.bankerRate_i = function () {
		var t = new eui.Label();
		this.bankerRate = t;
		t.height = 42;
		t.size = 40;
		t.text = "0%";
		t.textAlign = "center";
		t.textColor = 0x372e99;
		t.verticalAlign = "middle";
		t.width = 117;
		t.x = 643;
		t.y = 241.24;
		return t;
	};
	_proto.drawRate_i = function () {
		var t = new eui.Label();
		this.drawRate = t;
		t.height = 42;
		t.size = 40;
		t.text = "0%";
		t.textAlign = "center";
		t.textColor = 0x372E99;
		t.verticalAlign = "middle";
		t.width = 117;
		t.x = 919;
		t.y = 241.24;
		return t;
	};
	_proto.playerRate_i = function () {
		var t = new eui.Label();
		this.playerRate = t;
		t.anchorOffsetX = 0;
		t.height = 42;
		t.size = 40;
		t.text = "0%";
		t.textAlign = "center";
		t.textColor = 0x372E99;
		t.verticalAlign = "middle";
		t.width = 117;
		t.x = 1341;
		t.y = 241.24;
		return t;
	};
	_proto.banker_i = function () {
		var t = new eui.Label();
		this.banker = t;
		t.height = 40;
		t.size = 38;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302a75;
		t.verticalAlign = "middle";
		t.width = 50;
		t.x = 1177;
		t.y = 417.69;
		return t;
	};
	_proto.player_i = function () {
		var t = new eui.Label();
		this.player = t;
		t.height = 40;
		t.size = 38;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 50;
		t.x = 1352.34;
		t.y = 419.02;
		return t;
	};
	_proto.bankerD_i = function () {
		var t = new eui.Label();
		this.bankerD = t;
		t.height = 40;
		t.size = 38;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 50;
		t.x = 1177;
		t.y = 705.72;
		return t;
	};
	_proto.draw_i = function () {
		var t = new eui.Label();
		this.draw = t;
		t.height = 40;
		t.size = 38;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 50;
		t.x = 1177;
		t.y = 555;
		return t;
	};
	_proto.pointDraw_i = function () {
		var t = new eui.Label();
		this.pointDraw = t;
		t.height = 40;
		t.size = 38;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 50;
		t.x = 1352.26;
		t.y = 555;
		return t;
	};
	_proto.bankerB_i = function () {
		var t = new eui.Label();
		this.bankerB = t;
		t.height = 40;
		t.size = 38;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 50;
		t.x = 1177;
		t.y = 851.24;
		return t;
	};
	_proto.playerB_i = function () {
		var t = new eui.Label();
		this.playerB = t;
		t.height = 40;
		t.size = 38;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 50;
		t.x = 1352.34;
		t.y = 851.24;
		return t;
	};
	_proto.playD_i = function () {
		var t = new eui.Label();
		this.playD = t;
		t.height = 40;
		t.size = 38;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 50;
		t.x = 1352.34;
		t.y = 705.72;
		return t;
	};
	_proto.drawArea_i = function () {
		var t = new eui.Group();
		this.drawArea = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 579.37;
		t.width = 837.84;
		t.x = 248.03;
		t.y = 330.29;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.source = "xz_dh_png";
		t.x = 1317.02;
		t.y = 503.5;
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.source = "xz_h_png";
		t.x = 1143.35;
		t.y = 503.5;
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.source = "xz_x_png";
		t.x = 1317.02;
		t.y = 363;
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.source = "xz_z_png";
		t.x = 1143.35;
		t.y = 363;
		return t;
	};
	_proto._Image12_i = function () {
		var t = new eui.Image();
		t.source = "xz_xd_png";
		t.x = 1317.02;
		t.y = 649;
		return t;
	};
	_proto._Image13_i = function () {
		var t = new eui.Image();
		t.source = "xz_zd_png";
		t.x = 1143.35;
		t.y = 649;
		return t;
	};
	_proto._Image14_i = function () {
		var t = new eui.Image();
		t.source = "xz_ztw_png";
		t.x = 1143.35;
		t.y = 791.5;
		return t;
	};
	_proto._Image15_i = function () {
		var t = new eui.Image();
		t.source = "xz_xtw_png";
		t.x = 1317.02;
		t.y = 792.5;
		return t;
	};
	_proto.localHistory_i = function () {
		var t = new eui.Group();
		this.localHistory = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.visible = false;
		t.elementsContent = [this._Image16_i(),this._Image17_i(),this._Scroller1_i()];
		return t;
	};
	_proto._Image16_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "lsyk_bg_png";
		t.y = 203.24;
		return t;
	};
	_proto._Image17_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "title_text_lsyk_png";
		t.y = 130;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 603.33;
		t.horizontalCenter = 0;
		t.scrollPolicyH = "off";
		t.scrollPolicyV = "on";
		t.width = 1190;
		t.y = 297;
		t.viewport = this.localHistoryG_i();
		return t;
	};
	_proto.localHistoryG_i = function () {
		var t = new eui.Group();
		this.localHistoryG = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 609.33;
		t.width = 1180;
		t.x = -14;
		t.y = 0;
		return t;
	};
	_proto.settle_i = function () {
		var t = new eui.Group();
		this.settle = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.visible = false;
		t.elementsContent = [this._Image18_i(),this._Image19_i(),this.playerR1_i(),this.playerR2_i(),this.playerR3_i(),this.bankerR1_i(),this.bankerR2_i(),this.bankerR3_i(),this._Image20_i(),this.totalWin_i(),this._Image21_i(),this._Image22_i(),this._Image23_i(),this._Image24_i(),this._Image25_i(),this._Image26_i(),this._Image27_i(),this._Image28_i(),this.bankerWin_i(),this.bankerDWin_i(),this.bankerBWin_i(),this.drawWin_i(),this.playerWin_i(),this.playerDWin_i(),this.playBWin_i(),this.pointDrawWin_i()];
		return t;
	};
	_proto._Image18_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "tzjs_bg_png";
		t.y = 203.24;
		return t;
	};
	_proto._Image19_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "title_text_tzjs_png";
		t.y = 131.24;
		return t;
	};
	_proto.playerR1_i = function () {
		var t = new eui.Image();
		this.playerR1 = t;
		t.height = 125;
		t.source = "poker_back_png";
		t.width = 100;
		t.x = 456.05;
		t.y = 237.47;
		return t;
	};
	_proto.playerR2_i = function () {
		var t = new eui.Image();
		this.playerR2 = t;
		t.height = 125;
		t.source = "poker_back_png";
		t.width = 100;
		t.x = 554.72;
		t.y = 237.47;
		return t;
	};
	_proto.playerR3_i = function () {
		var t = new eui.Image();
		this.playerR3 = t;
		t.height = 125;
		t.source = "poker_back_png";
		t.width = 100;
		t.x = 651.33;
		t.y = 237.47;
		return t;
	};
	_proto.bankerR1_i = function () {
		var t = new eui.Image();
		this.bankerR1 = t;
		t.height = 125;
		t.source = "poker_back_png";
		t.width = 100;
		t.x = 962.04;
		t.y = 237.47;
		return t;
	};
	_proto.bankerR2_i = function () {
		var t = new eui.Image();
		this.bankerR2 = t;
		t.height = 125;
		t.source = "poker_back_png";
		t.width = 100;
		t.x = 1060.71;
		t.y = 237.47;
		return t;
	};
	_proto.bankerR3_i = function () {
		var t = new eui.Image();
		this.bankerR3 = t;
		t.height = 125;
		t.source = "poker_back_png";
		t.width = 100;
		t.x = 1157.32;
		t.y = 237.47;
		return t;
	};
	_proto._Image20_i = function () {
		var t = new eui.Image();
		t.source = "hjsy_png";
		t.x = 312;
		t.y = 439.06;
		return t;
	};
	_proto.totalWin_i = function () {
		var t = new eui.Label();
		this.totalWin = t;
		t.anchorOffsetX = 0;
		t.height = 50;
		t.size = 40;
		t.text = "+0";
		t.textAlign = "left";
		t.textColor = 0x5e44e6;
		t.verticalAlign = "middle";
		t.width = 358;
		t.x = 535;
		t.y = 433.02;
		return t;
	};
	_proto._Image21_i = function () {
		var t = new eui.Image();
		t.source = "xz_z_png";
		t.x = 312;
		t.y = 537;
		return t;
	};
	_proto._Image22_i = function () {
		var t = new eui.Image();
		t.source = "xz_zd_png";
		t.x = 312;
		t.y = 639;
		return t;
	};
	_proto._Image23_i = function () {
		var t = new eui.Image();
		t.source = "xz_xtw_png";
		t.x = 700;
		t.y = 738;
		return t;
	};
	_proto._Image24_i = function () {
		var t = new eui.Image();
		t.source = "xz_ztw_png";
		t.x = 312;
		t.y = 738;
		return t;
	};
	_proto._Image25_i = function () {
		var t = new eui.Image();
		t.source = "xz_h_png";
		t.x = 312;
		t.y = 838;
		return t;
	};
	_proto._Image26_i = function () {
		var t = new eui.Image();
		t.source = "xz_x_png";
		t.x = 700;
		t.y = 537;
		return t;
	};
	_proto._Image27_i = function () {
		var t = new eui.Image();
		t.source = "xz_dh_png";
		t.x = 700;
		t.y = 838;
		return t;
	};
	_proto._Image28_i = function () {
		var t = new eui.Image();
		t.source = "xz_xd_png";
		t.x = 700;
		t.y = 639;
		return t;
	};
	_proto.bankerWin_i = function () {
		var t = new eui.Label();
		this.bankerWin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.size = 34;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302a75;
		t.verticalAlign = "middle";
		t.width = 103;
		t.x = 464;
		t.y = 537;
		return t;
	};
	_proto.bankerDWin_i = function () {
		var t = new eui.Label();
		this.bankerDWin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.size = 34;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 103;
		t.x = 464;
		t.y = 639;
		return t;
	};
	_proto.bankerBWin_i = function () {
		var t = new eui.Label();
		this.bankerBWin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.size = 34;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 103;
		t.x = 464;
		t.y = 738;
		return t;
	};
	_proto.drawWin_i = function () {
		var t = new eui.Label();
		this.drawWin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.size = 34;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 103;
		t.x = 464;
		t.y = 838;
		return t;
	};
	_proto.playerWin_i = function () {
		var t = new eui.Label();
		this.playerWin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.size = 34;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 103;
		t.x = 846;
		t.y = 537;
		return t;
	};
	_proto.playerDWin_i = function () {
		var t = new eui.Label();
		this.playerDWin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.size = 34;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 103;
		t.x = 846;
		t.y = 639;
		return t;
	};
	_proto.playBWin_i = function () {
		var t = new eui.Label();
		this.playBWin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.size = 34;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 103;
		t.x = 846;
		t.y = 738;
		return t;
	};
	_proto.pointDrawWin_i = function () {
		var t = new eui.Label();
		this.pointDrawWin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.size = 34;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.width = 103;
		t.x = 846;
		t.y = 838;
		return t;
	};
	_proto.tips_i = function () {
		var t = new eui.Group();
		this.tips = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 714;
		t.visible = false;
		t.width = 1218;
		t.x = 246;
		t.y = 208;
		t.elementsContent = [this._Image29_i(),this._Image30_i(),this._Scroller2_i()];
		return t;
	};
	_proto._Image29_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.fillMode = "scale";
		t.horizontalCenter = 4;
		t.scale9Grid = new egret.Rectangle(40,40,2,10);
		t.source = "lsyk_wf_bg_png";
		t.width = 1252;
		t.y = -6.5;
		return t;
	};
	_proto._Image30_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "title_text_wf_png";
		t.y = -78;
		return t;
	};
	_proto._Scroller2_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 675.33;
		t.horizontalCenter = 5;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 1204;
		t.x = 32;
		t.y = 9.37;
		t.viewport = this._Group1_i();
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 712;
		t.width = 244;
		t.x = 0;
		t.y = -10;
		t.elementsContent = [this._Label1_i(),this.tipsContent_i()];
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.size = 38;
		t.text = "生死百家乐游戏说明";
		t.textColor = 0x5e44e6;
		t.x = 45;
		t.y = 3.04;
		return t;
	};
	_proto.tipsContent_i = function () {
		var t = new eui.Label();
		this.tipsContent = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.lineSpacing = 34;
		t.size = 34;
		t.text = "";
		t.textColor = 0x302a75;
		t.width = 1126;
		t.x = 45;
		t.y = 60.51;
		return t;
	};
	_proto.sourceCodeG_i = function () {
		var t = new eui.Group();
		this.sourceCodeG = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 702;
		t.horizontalCenter = 0;
		t.visible = false;
		t.width = 1208;
		t.y = 213;
		t.elementsContent = [this._Image31_i(),this._Scroller3_i()];
		return t;
	};
	_proto._Image31_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.fillMode = "scale";
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(40,40,2,10);
		t.source = "lsyk_wf_bg_png";
		t.width = 1252;
		t.y = -9.42;
		return t;
	};
	_proto._Scroller3_i = function () {
		var t = new eui.Scroller();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 667.27;
		t.horizontalCenter = 0;
		t.width = 1189.7;
		t.y = 12.09;
		t.viewport = this._Group2_i();
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.width = 330;
		t.elementsContent = [this.sourceCodeLabel_i()];
		return t;
	};
	_proto.sourceCodeLabel_i = function () {
		var t = new eui.Label();
		this.sourceCodeLabel = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.horizontalCenter = 0.14999999999997726;
		t.lineSpacing = 34;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 34;
		t.text = "";
		t.textColor = 0x302A75;
		t.width = 1180;
		t.y = 8.24;
		return t;
	};
	_proto.gameInfo_i = function () {
		var t = new eui.Group();
		this.gameInfo = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 714;
		t.visible = false;
		t.width = 1218;
		t.x = 256;
		t.y = 218;
		t.elementsContent = [this._Image32_i(),this.gameName_i(),this.creator_i(),this.contractAddr_i(),this.createTime_i(),this.balance_i(),this.historyCoin_i(),this._Image33_i(),this._Image34_i(),this._Image35_i(),this._Image36_i(),this._Image37_i(),this._Image38_i()];
		return t;
	};
	_proto._Image32_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.fillMode = "scale";
		t.horizontalCenter = -6;
		t.scale9Grid = new egret.Rectangle(40,40,2,10);
		t.source = "lsyk_wf_bg_png";
		t.width = 1252;
		t.y = -15.62;
		return t;
	};
	_proto.gameName_i = function () {
		var t = new eui.Label();
		this.gameName = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 70;
		t.left = 313;
		t.lineSpacing = 34;
		t.size = 34;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.verticalCenter = -262;
		t.width = 826;
		return t;
	};
	_proto.creator_i = function () {
		var t = new eui.Label();
		this.creator = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 70;
		t.left = 313;
		t.lineSpacing = 34;
		t.size = 34;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.verticalCenter = -174;
		t.width = 874;
		return t;
	};
	_proto.contractAddr_i = function () {
		var t = new eui.Label();
		this.contractAddr = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 70;
		t.left = 313;
		t.lineSpacing = 34;
		t.size = 34;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.verticalCenter = -76;
		t.width = 876;
		return t;
	};
	_proto.createTime_i = function () {
		var t = new eui.Label();
		this.createTime = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 70;
		t.left = 313;
		t.lineSpacing = 34;
		t.size = 34;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.verticalCenter = 22;
		t.width = 826;
		return t;
	};
	_proto.balance_i = function () {
		var t = new eui.Label();
		this.balance = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 70;
		t.left = 313;
		t.lineSpacing = 34;
		t.size = 34;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.verticalCenter = 122;
		t.width = 826;
		return t;
	};
	_proto.historyCoin_i = function () {
		var t = new eui.Label();
		this.historyCoin = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 70;
		t.left = 313;
		t.lineSpacing = 34;
		t.size = 34;
		t.text = "";
		t.textAlign = "left";
		t.textColor = 0x302A75;
		t.verticalAlign = "middle";
		t.verticalCenter = 216;
		t.width = 826;
		return t;
	};
	_proto._Image33_i = function () {
		var t = new eui.Image();
		t.source = "yyxx_yym_png";
		t.x = 47;
		t.y = 76;
		return t;
	};
	_proto._Image34_i = function () {
		var t = new eui.Image();
		t.source = "yyxx_yydz_png";
		t.x = 46;
		t.y = 262;
		return t;
	};
	_proto._Image35_i = function () {
		var t = new eui.Image();
		t.source = "yyxx_xzzje_png";
		t.x = 48;
		t.y = 555;
		return t;
	};
	_proto._Image36_i = function () {
		var t = new eui.Image();
		t.source = "yyxx_jcye_png";
		t.x = 48;
		t.y = 460;
		return t;
	};
	_proto._Image37_i = function () {
		var t = new eui.Image();
		t.source = "yyxx_cjsj_png";
		t.x = 48;
		t.y = 360;
		return t;
	};
	_proto._Image38_i = function () {
		var t = new eui.Image();
		t.source = "yyxx_cjrdz_png";
		t.x = 48;
		t.y = 164;
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Image();
		this.close = t;
		t.source = "close_png";
		t.x = 1462.18;
		t.y = 110.24;
		return t;
	};
	return infoPanal;
})(eui.Skin);generateEUI.paths['resource/eui_skins/custom/Loading.exml'] = window.Loading = (function (_super) {
	__extends(Loading, _super);
	function Loading() {
		_super.call(this);
		this.skinParts = ["loop","rect","label","light"];
		
		this.height = 1080;
		this.width = 1716;
		this.loop_i();
		this.elementsContent = [this.rect_i(),this.label_i(),this._Image1_i(),this.light_i()];
		
		eui.Binding.$bindProperties(this, ["light"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [90],[],this._Object1,"rotation");
		eui.Binding.$bindProperties(this, [450],[],this._Object2,"rotation");
	}
	var _proto = Loading.prototype;

	_proto.loop_i = function () {
		var t = new egret.tween.TweenGroup();
		this.loop = t;
		t.items = [this._TweenItem1_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._Set1_i(),this._To1_i()];
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 1600;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto.rect_i = function () {
		var t = new eui.Rect();
		this.rect = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.fillAlpha = 0.7;
		t.fillColor = 0x000000;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto.label_i = function () {
		var t = new eui.Label();
		this.label = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 75.45;
		t.horizontalCenter = 0;
		t.rotation = 89.68;
		t.text = "加载中···";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		t.visible = false;
		t.width = 204.3;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.rotation = 0;
		t.source = "loading_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.light_i = function () {
		var t = new eui.Image();
		this.light = t;
		t.horizontalCenter = 0;
		t.rotation = 0;
		t.source = "loading_light_png";
		t.verticalCenter = -6;
		return t;
	};
	return Loading;
})(eui.Skin);generateEUI.paths['resource/eui_skins/custom/MenuUI.exml'] = window.MenuUI = (function (_super) {
	__extends(MenuUI, _super);
	function MenuUI() {
		_super.call(this);
		this.skinParts = ["goHome","tips","gameInfo","sourceCode"];
		
		this.height = 129;
		this.width = 480;
		this.elementsContent = [this.goHome_i(),this.tips_i(),this.gameInfo_i(),this.sourceCode_i()];
	}
	var _proto = MenuUI.prototype;

	_proto.goHome_i = function () {
		var t = new eui.Image();
		this.goHome = t;
		t.source = "icon_home_png";
		t.x = 9;
		t.y = 26;
		return t;
	};
	_proto.tips_i = function () {
		var t = new eui.Image();
		this.tips = t;
		t.source = "icon_help_png";
		t.x = 249;
		t.y = 26;
		return t;
	};
	_proto.gameInfo_i = function () {
		var t = new eui.Image();
		this.gameInfo = t;
		t.source = "icon_zjxx_png";
		t.x = 129;
		t.y = 26;
		return t;
	};
	_proto.sourceCode_i = function () {
		var t = new eui.Image();
		this.sourceCode = t;
		t.source = "icon_ym_png";
		t.x = 369;
		t.y = 26;
		return t;
	};
	return MenuUI;
})(eui.Skin);generateEUI.paths['resource/eui_skins/custom/Password.exml'] = window.Password = (function (_super) {
	__extends(Password, _super);
	function Password() {
		_super.call(this);
		this.skinParts = ["btn","label","close"];
		
		this.height = 1080;
		this.width = 1716;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this.btn_i(),this._Rect2_i(),this.label_i(),this._Label1_i(),this.close_i()];
	}
	var _proto = Password.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.bottom = 0;
		t.fillAlpha = 0.52;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.source = "small_pop_ups_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.btn_i = function () {
		var t = new eui.Image();
		this.btn = t;
		t.horizontalCenter = 0.5;
		t.source = "btn_sure_png";
		t.verticalCenter = 122;
		t.y = 600;
		return t;
	};
	_proto._Rect2_i = function () {
		var t = new eui.Rect();
		t.ellipseHeight = 40;
		t.ellipseWidth = 50;
		t.fillColor = 0xa095d8;
		t.height = 100;
		t.horizontalCenter = 0;
		t.width = 500;
		t.y = 465;
		return t;
	};
	_proto.label_i = function () {
		var t = new eui.EditableText();
		this.label = t;
		t.alpha = 1;
		t.height = 100;
		t.horizontalCenter = "0";
		t.prompt = "请输入钱包密码";
		t.promptColor = 0xcccccc;
		t.size = 40;
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 500;
		t.y = 465;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.height = 40;
		t.size = 30;
		t.text = "请解锁";
		t.x = 500;
		t.y = 388;
		return t;
	};
	_proto.close_i = function () {
		var t = new eui.Image();
		this.close = t;
		t.horizontalCenter = 332.5;
		t.source = "close_png";
		t.y = 356;
		return t;
	};
	return Password;
})(eui.Skin);generateEUI.paths['resource/eui_skins/custom/TableUI.exml'] = window.TableUI = (function (_super) {
	__extends(TableUI, _super);
	function TableUI() {
		_super.call(this);
		this.skinParts = ["pokerAnimal","fanalTurnP3","fanalTurnB3","playerPokerA1","playerPokerA2","playerPokerA3","bankerPokerA1","bankerPokerA2","bankerPokerA3","playPoint","bankerPoint","pokerAnimalGroup","historyBtn","localHistoryBtn","pool","myBalance","tipsLabel","timeNum","chip1","chip2","chip3","chip4","chip1Active","chip2Active","chip3Active","chip4Active","chip1Label","chip2Label","chip3Label","chip4Label","playerDBet","bankerDBet","playerBet","bankerBet","drawBet","pointDrawBet","playerBBet","bankerBBet","tip_bg","addPokerTxt"];
		
		this.height = 1080;
		this.width = 1716;
		this.pokerAnimal_i();
		this.fanalTurnP3_i();
		this.fanalTurnB3_i();
		this.elementsContent = [this._Image1_i(),this.pokerAnimalGroup_i(),this.historyBtn_i(),this.localHistoryBtn_i(),this._Image3_i(),this._Image4_i(),this.pool_i(),this._Image5_i(),this._Image6_i(),this.myBalance_i(),this._Image7_i(),this.tipsLabel_i(),this.timeNum_i(),this.chip1_i(),this.chip2_i(),this.chip3_i(),this.chip4_i(),this.chip1Active_i(),this.chip2Active_i(),this.chip3Active_i(),this.chip4Active_i(),this.chip1Label_i(),this.chip2Label_i(),this.chip3Label_i(),this.chip4Label_i(),this.playerDBet_i(),this.bankerDBet_i(),this.playerBet_i(),this.bankerBet_i(),this.drawBet_i(),this.pointDrawBet_i(),this.playerBBet_i(),this.bankerBBet_i(),this.tip_bg_i(),this.addPokerTxt_i()];
		
		eui.Binding.$bindProperties(this, ["playerPokerA1"],[0],this._TweenItem1,"target");
		eui.Binding.$bindProperties(this, [859],[],this._Object1,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object1,"y");
		eui.Binding.$bindProperties(this, [859],[],this._Object2,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object2,"y");
		eui.Binding.$bindProperties(this, [404],[],this._Object3,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object3,"y");
		eui.Binding.$bindProperties(this, ["playerPokerA2"],[0],this._TweenItem2,"target");
		eui.Binding.$bindProperties(this, [859],[],this._Object4,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object4,"y");
		eui.Binding.$bindProperties(this, [859],[],this._Object5,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object5,"y");
		eui.Binding.$bindProperties(this, [500],[],this._Object6,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object6,"y");
		eui.Binding.$bindProperties(this, ["bankerPokerA1"],[0],this._TweenItem3,"target");
		eui.Binding.$bindProperties(this, [859],[],this._Object7,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object7,"y");
		eui.Binding.$bindProperties(this, [859],[],this._Object8,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object8,"y");
		eui.Binding.$bindProperties(this, [1309],[],this._Object9,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object9,"y");
		eui.Binding.$bindProperties(this, ["bankerPokerA2"],[0],this._TweenItem4,"target");
		eui.Binding.$bindProperties(this, [859],[],this._Object10,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object10,"y");
		eui.Binding.$bindProperties(this, [859],[],this._Object11,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object11,"y");
		eui.Binding.$bindProperties(this, [1213],[],this._Object12,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object12,"y");
		eui.Binding.$bindProperties(this, ["playerPokerA3"],[0],this._TweenItem5,"target");
		eui.Binding.$bindProperties(this, [859],[],this._Object13,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object13,"y");
		eui.Binding.$bindProperties(this, [859],[],this._Object14,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object14,"y");
		eui.Binding.$bindProperties(this, [596],[],this._Object15,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object15,"y");
		eui.Binding.$bindProperties(this, ["bankerPokerA3"],[0],this._TweenItem6,"target");
		eui.Binding.$bindProperties(this, [859],[],this._Object16,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object16,"y");
		eui.Binding.$bindProperties(this, [859],[],this._Object17,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object17,"y");
		eui.Binding.$bindProperties(this, [1117],[],this._Object18,"x");
		eui.Binding.$bindProperties(this, [555],[],this._Object18,"y");
	}
	var _proto = TableUI.prototype;

	_proto.pokerAnimal_i = function () {
		var t = new egret.tween.TweenGroup();
		this.pokerAnimal = t;
		t.items = [this._TweenItem1_i(),this._TweenItem2_i(),this._TweenItem3_i(),this._TweenItem4_i()];
		return t;
	};
	_proto._TweenItem1_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem1 = t;
		t.paths = [this._To1_i(),this._To2_i(),this._To3_i()];
		return t;
	};
	_proto._To1_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.ease = "quadInOut";
		t.props = this._Object1_i();
		return t;
	};
	_proto._Object1_i = function () {
		var t = {};
		this._Object1 = t;
		return t;
	};
	_proto._To2_i = function () {
		var t = new egret.tween.To();
		t.duration = 150;
		t.props = this._Object2_i();
		return t;
	};
	_proto._Object2_i = function () {
		var t = {};
		this._Object2 = t;
		return t;
	};
	_proto._To3_i = function () {
		var t = new egret.tween.To();
		t.duration = 400;
		t.props = this._Object3_i();
		return t;
	};
	_proto._Object3_i = function () {
		var t = {};
		this._Object3 = t;
		return t;
	};
	_proto._TweenItem2_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem2 = t;
		t.paths = [this._Wait1_i(),this._Set1_i(),this._To4_i(),this._To5_i(),this._To6_i()];
		return t;
	};
	_proto._Wait1_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 1800;
		return t;
	};
	_proto._Set1_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To4_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object4_i();
		return t;
	};
	_proto._Object4_i = function () {
		var t = {};
		this._Object4 = t;
		return t;
	};
	_proto._To5_i = function () {
		var t = new egret.tween.To();
		t.duration = 150;
		t.props = this._Object5_i();
		return t;
	};
	_proto._Object5_i = function () {
		var t = {};
		this._Object5 = t;
		return t;
	};
	_proto._To6_i = function () {
		var t = new egret.tween.To();
		t.duration = 400;
		t.props = this._Object6_i();
		return t;
	};
	_proto._Object6_i = function () {
		var t = {};
		this._Object6 = t;
		return t;
	};
	_proto._TweenItem3_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem3 = t;
		t.paths = [this._Wait2_i(),this._Set2_i(),this._To7_i(),this._To8_i(),this._To9_i()];
		return t;
	};
	_proto._Wait2_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 900;
		return t;
	};
	_proto._Set2_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To7_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object7_i();
		return t;
	};
	_proto._Object7_i = function () {
		var t = {};
		this._Object7 = t;
		return t;
	};
	_proto._To8_i = function () {
		var t = new egret.tween.To();
		t.duration = 150;
		t.props = this._Object8_i();
		return t;
	};
	_proto._Object8_i = function () {
		var t = {};
		this._Object8 = t;
		return t;
	};
	_proto._To9_i = function () {
		var t = new egret.tween.To();
		t.duration = 400;
		t.props = this._Object9_i();
		return t;
	};
	_proto._Object9_i = function () {
		var t = {};
		this._Object9 = t;
		return t;
	};
	_proto._TweenItem4_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem4 = t;
		t.paths = [this._Wait3_i(),this._Set3_i(),this._To10_i(),this._To11_i(),this._To12_i()];
		return t;
	};
	_proto._Wait3_i = function () {
		var t = new egret.tween.Wait();
		t.duration = 2700;
		return t;
	};
	_proto._Set3_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To10_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object10_i();
		return t;
	};
	_proto._Object10_i = function () {
		var t = {};
		this._Object10 = t;
		return t;
	};
	_proto._To11_i = function () {
		var t = new egret.tween.To();
		t.duration = 150;
		t.props = this._Object11_i();
		return t;
	};
	_proto._Object11_i = function () {
		var t = {};
		this._Object11 = t;
		return t;
	};
	_proto._To12_i = function () {
		var t = new egret.tween.To();
		t.duration = 400;
		t.props = this._Object12_i();
		return t;
	};
	_proto._Object12_i = function () {
		var t = {};
		this._Object12 = t;
		return t;
	};
	_proto.fanalTurnP3_i = function () {
		var t = new egret.tween.TweenGroup();
		this.fanalTurnP3 = t;
		t.items = [this._TweenItem5_i()];
		return t;
	};
	_proto._TweenItem5_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem5 = t;
		t.paths = [this._Set4_i(),this._To13_i(),this._To14_i(),this._To15_i()];
		return t;
	};
	_proto._Set4_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To13_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object13_i();
		return t;
	};
	_proto._Object13_i = function () {
		var t = {};
		this._Object13 = t;
		return t;
	};
	_proto._To14_i = function () {
		var t = new egret.tween.To();
		t.duration = 150;
		t.props = this._Object14_i();
		return t;
	};
	_proto._Object14_i = function () {
		var t = {};
		this._Object14 = t;
		return t;
	};
	_proto._To15_i = function () {
		var t = new egret.tween.To();
		t.duration = 400;
		t.props = this._Object15_i();
		return t;
	};
	_proto._Object15_i = function () {
		var t = {};
		this._Object15 = t;
		return t;
	};
	_proto.fanalTurnB3_i = function () {
		var t = new egret.tween.TweenGroup();
		this.fanalTurnB3 = t;
		t.items = [this._TweenItem6_i()];
		return t;
	};
	_proto._TweenItem6_i = function () {
		var t = new egret.tween.TweenItem();
		this._TweenItem6 = t;
		t.paths = [this._Set5_i(),this._To16_i(),this._To17_i(),this._To18_i()];
		return t;
	};
	_proto._Set5_i = function () {
		var t = new egret.tween.Set();
		return t;
	};
	_proto._To16_i = function () {
		var t = new egret.tween.To();
		t.duration = 350;
		t.props = this._Object16_i();
		return t;
	};
	_proto._Object16_i = function () {
		var t = {};
		this._Object16 = t;
		return t;
	};
	_proto._To17_i = function () {
		var t = new egret.tween.To();
		t.duration = 150;
		t.props = this._Object17_i();
		return t;
	};
	_proto._Object17_i = function () {
		var t = {};
		this._Object17 = t;
		return t;
	};
	_proto._To18_i = function () {
		var t = new egret.tween.To();
		t.duration = 400;
		t.props = this._Object18_i();
		return t;
	};
	_proto._Object18_i = function () {
		var t = {};
		this._Object18 = t;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.right = 0;
		t.source = "table_png";
		t.top = 0;
		return t;
	};
	_proto.pokerAnimalGroup_i = function () {
		var t = new eui.Group();
		this.pokerAnimalGroup = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.visible = false;
		t.elementsContent = [this.playerPokerA1_i(),this.playerPokerA2_i(),this.playerPokerA3_i(),this.bankerPokerA1_i(),this.bankerPokerA2_i(),this.bankerPokerA3_i(),this.playPoint_i(),this.bankerPoint_i(),this._Image2_i()];
		return t;
	};
	_proto.playerPokerA1_i = function () {
		var t = new eui.Image();
		this.playerPokerA1 = t;
		t.anchorOffsetX = 55;
		t.anchorOffsetY = 69;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "poker_back_png";
		t.x = 859;
		t.y = 350;
		return t;
	};
	_proto.playerPokerA2_i = function () {
		var t = new eui.Image();
		this.playerPokerA2 = t;
		t.anchorOffsetX = 55;
		t.anchorOffsetY = 69;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "poker_back_png";
		t.x = 859;
		t.y = 350;
		return t;
	};
	_proto.playerPokerA3_i = function () {
		var t = new eui.Image();
		this.playerPokerA3 = t;
		t.anchorOffsetX = 55;
		t.anchorOffsetY = 69;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "poker_back_png";
		t.x = 859;
		t.y = 350;
		return t;
	};
	_proto.bankerPokerA1_i = function () {
		var t = new eui.Image();
		this.bankerPokerA1 = t;
		t.anchorOffsetX = 55;
		t.anchorOffsetY = 69;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "poker_back_png";
		t.x = 859;
		t.y = 350;
		return t;
	};
	_proto.bankerPokerA2_i = function () {
		var t = new eui.Image();
		this.bankerPokerA2 = t;
		t.anchorOffsetX = 55;
		t.anchorOffsetY = 69;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "poker_back_png";
		t.x = 859;
		t.y = 350;
		return t;
	};
	_proto.bankerPokerA3_i = function () {
		var t = new eui.Image();
		this.bankerPokerA3 = t;
		t.anchorOffsetX = 55;
		t.anchorOffsetY = 69;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "poker_back_png";
		t.x = 859;
		t.y = 350;
		return t;
	};
	_proto.playPoint_i = function () {
		var t = new eui.Label();
		this.playPoint = t;
		t.bold = true;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0xeabf4e;
		t.verticalAlign = "middle";
		t.width = 100;
		t.x = 404.46;
		t.y = 620;
		return t;
	};
	_proto.bankerPoint_i = function () {
		var t = new eui.Label();
		this.bankerPoint = t;
		t.bold = true;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0xeabf4e;
		t.verticalAlign = "middle";
		t.width = 100;
		t.x = 1211.5;
		t.y = 620;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 55;
		t.anchorOffsetY = 69;
		t.source = "poker_back_png";
		t.x = 859;
		t.y = 350;
		return t;
	};
	_proto.historyBtn_i = function () {
		var t = new eui.Image();
		this.historyBtn = t;
		t.source = "btn_dzld_png";
		t.x = 806;
		t.y = 33;
		return t;
	};
	_proto.localHistoryBtn_i = function () {
		var t = new eui.Image();
		this.localHistoryBtn = t;
		t.source = "btn_lsyk_png";
		t.x = 576;
		t.y = 33;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "jc_fof_bg_png";
		t.x = 1110;
		t.y = 40;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "jc_fof_bg_png";
		t.x = 1413;
		t.y = 40;
		return t;
	};
	_proto.pool_i = function () {
		var t = new eui.Label();
		this.pool = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "SourceHanSansCN-Regular";
		t.height = 57;
		t.size = 35;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x8FA6CF;
		t.verticalAlign = "middle";
		t.width = 170;
		t.x = 1153;
		t.y = 44;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "jc_png";
		t.x = 1066.5;
		t.y = 33;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.source = "fof_png";
		t.x = 1369.5;
		t.y = 33;
		return t;
	};
	_proto.myBalance_i = function () {
		var t = new eui.Label();
		this.myBalance = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "SourceHanSansCN-Regular";
		t.height = 57;
		t.size = 35;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x8fa6cf;
		t.verticalAlign = "middle";
		t.width = 170;
		t.x = 1456.5;
		t.y = 44;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.source = "clock_png";
		t.x = 732;
		t.y = 168;
		return t;
	};
	_proto.tipsLabel_i = function () {
		var t = new eui.Label();
		this.tipsLabel = t;
		t.size = 35;
		t.text = "下注时间";
		t.textColor = 0xfdf2b7;
		t.x = 869;
		t.y = 211;
		return t;
	};
	_proto.timeNum_i = function () {
		var t = new eui.Label();
		this.timeNum = t;
		t.anchorOffsetX = 0;
		t.height = 33;
		t.size = 33;
		t.text = "0S";
		t.textAlign = "center";
		t.verticalAlign = "middle";
		t.width = 59;
		t.x = 761.5;
		t.y = 212;
		return t;
	};
	_proto.chip1_i = function () {
		var t = new eui.Image();
		this.chip1 = t;
		t.source = "chip1_png";
		t.x = 279;
		t.y = 795;
		return t;
	};
	_proto.chip2_i = function () {
		var t = new eui.Image();
		this.chip2 = t;
		t.source = "chip2_png";
		t.x = 584.66;
		t.y = 795;
		return t;
	};
	_proto.chip3_i = function () {
		var t = new eui.Image();
		this.chip3 = t;
		t.source = "chip3_png";
		t.x = 896.84;
		t.y = 795;
		return t;
	};
	_proto.chip4_i = function () {
		var t = new eui.Image();
		this.chip4 = t;
		t.source = "chip4_png";
		t.x = 1212;
		t.y = 795;
		return t;
	};
	_proto.chip1Active_i = function () {
		var t = new eui.Image();
		this.chip1Active = t;
		t.source = "chip1_xz_png";
		t.visible = false;
		t.x = 265.5;
		t.y = 766.5;
		return t;
	};
	_proto.chip2Active_i = function () {
		var t = new eui.Image();
		this.chip2Active = t;
		t.source = "chip2_xz_png";
		t.visible = false;
		t.x = 571.66;
		t.y = 766.5;
		return t;
	};
	_proto.chip3Active_i = function () {
		var t = new eui.Image();
		this.chip3Active = t;
		t.source = "chip3_xz_png";
		t.visible = false;
		t.x = 883.84;
		t.y = 766.5;
		return t;
	};
	_proto.chip4Active_i = function () {
		var t = new eui.Image();
		this.chip4Active = t;
		t.source = "chip4_xz_png";
		t.visible = false;
		t.x = 1199;
		t.y = 766.5;
		return t;
	};
	_proto.chip1Label_i = function () {
		var t = new eui.Label();
		this.chip1Label = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "FlamaCondensed-Bold";
		t.height = 219;
		t.name = "chip1Label";
		t.size = 74;
		t.text = "1";
		t.textAlign = "center";
		t.textColor = 0xfefefe;
		t.verticalAlign = "middle";
		t.width = 219;
		t.x = 288.5;
		t.y = 790.5;
		return t;
	};
	_proto.chip2Label_i = function () {
		var t = new eui.Label();
		this.chip2Label = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "FlamaCondensed-Bold";
		t.height = 219;
		t.name = "chip2Label";
		t.size = 74;
		t.text = "1";
		t.textAlign = "center";
		t.textColor = 0xFEFEFE;
		t.verticalAlign = "middle";
		t.width = 219;
		t.x = 594.16;
		t.y = 790.5;
		return t;
	};
	_proto.chip3Label_i = function () {
		var t = new eui.Label();
		this.chip3Label = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "FlamaCondensed-Bold";
		t.height = 219;
		t.name = "chip3Label";
		t.size = 74;
		t.text = "1";
		t.textAlign = "center";
		t.textColor = 0xFEFEFE;
		t.verticalAlign = "middle";
		t.width = 219;
		t.x = 906.34;
		t.y = 790.5;
		return t;
	};
	_proto.chip4Label_i = function () {
		var t = new eui.Label();
		this.chip4Label = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.fontFamily = "FlamaCondensed-Bold";
		t.height = 219;
		t.name = "chip4Label";
		t.size = 74;
		t.text = "1";
		t.textAlign = "center";
		t.textColor = 0xFEFEFE;
		t.verticalAlign = "middle";
		t.width = 219;
		t.x = 1221.5;
		t.y = 790.5;
		return t;
	};
	_proto.playerDBet_i = function () {
		var t = new eui.Rect();
		this.playerDBet = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xffffff;
		t.height = 116.97;
		t.name = "playerDBet";
		t.width = 413.94;
		t.x = 372.39;
		t.y = 276.91;
		return t;
	};
	_proto.bankerDBet_i = function () {
		var t = new eui.Rect();
		this.bankerDBet = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 116.97;
		t.name = "bankerDBet";
		t.width = 439.7;
		t.x = 913.24;
		t.y = 276.91;
		return t;
	};
	_proto.playerBet_i = function () {
		var t = new eui.Rect();
		this.playerBet = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 148.79;
		t.name = "playerBet";
		t.width = 362.43;
		t.x = 194.96;
		t.y = 439.94;
		return t;
	};
	_proto.bankerBet_i = function () {
		var t = new eui.Rect();
		this.bankerBet = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 148.79;
		t.name = "bankerBet";
		t.width = 332.13;
		t.x = 1192.93;
		t.y = 439.94;
		return t;
	};
	_proto.drawBet_i = function () {
		var t = new eui.Rect();
		this.drawBet = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 77.58;
		t.name = "drawBet";
		t.width = 332.13;
		t.x = 683.93;
		t.y = 426.15;
		return t;
	};
	_proto.pointDrawBet_i = function () {
		var t = new eui.Rect();
		this.pointDrawBet = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 77.58;
		t.name = "pointDrawBet";
		t.width = 332.13;
		t.x = 684.47;
		t.y = 523.46;
		return t;
	};
	_proto.playerBBet_i = function () {
		var t = new eui.Rect();
		this.playerBBet = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 109.4;
		t.name = "playerBBet";
		t.width = 353.34;
		t.x = 397.5;
		t.y = 633.46;
		return t;
	};
	_proto.bankerBBet_i = function () {
		var t = new eui.Rect();
		this.bankerBBet = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillAlpha = 0;
		t.fillColor = 0xFFFFFF;
		t.height = 109.4;
		t.name = "bankerBBet";
		t.width = 353.34;
		t.x = 968.54;
		t.y = 634.98;
		return t;
	};
	_proto.tip_bg_i = function () {
		var t = new eui.Image();
		this.tip_bg = t;
		t.height = 87;
		t.horizontalCenter = -7;
		t.source = "tip_bg_png";
		t.verticalCenter = -129.5;
		t.visible = false;
		t.width = 918;
		return t;
	};
	_proto.addPokerTxt_i = function () {
		var t = new eui.Label();
		this.addPokerTxt = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.height = 64.85;
		t.horizontalCenter = 0;
		t.text = "txt";
		t.textAlign = "center";
		t.textColor = 0xc6e810;
		t.verticalAlign = "middle";
		t.visible = false;
		t.width = 567.94;
		t.y = 382.86;
		return t;
	};
	return TableUI;
})(eui.Skin);